import { lightTheme,darkTheme } from "./theme";

export {lightTheme,darkTheme}