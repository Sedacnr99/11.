import styled from "styled-components";

export const StyledCard = styled.section`

`