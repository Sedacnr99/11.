const Data ={
    PayItems : [
        
        {
            id:1,
            pay: "150₺",
            imageId:"./public/images/kadayifDolmasi.jpg",
            text:"kadayıf dolmasında büyük indirim!!",
        },
        {
            id:2,
            pay:"100₺",
            imageId:"./public/images/yaprakSarma.jpg",
            text:"Yaprak sarmada kilo başına satış fiyatında büyük indirim, stoklarla sınırlıdır ve ön sipariş gereklidir.",
        },
        {
            id:3,
            pay:"950",
            imageId:"./public/images/baklava.jpg",
            name:" Fırsat ürünü 1",
            text:"1 kilo baklava ve 2 kilo sarma fırsat ürünü olarak sitemizde yerini almıştır.",
        },
        {
            id:4,
            pay:"1050",
            imageId:"./public/images/lahmacun.jpg",
            name:" Fırsat ürünü 2",
            text:"10 adet lahmacun ve yanında yeşillik salatası ile sadece 1050 tl",
        },
    ]
}

export default Data

