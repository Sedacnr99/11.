import styled from "styled-components";
import { StyledCard } from "./Slider.styled";
import SlideCard from "./SliderCard";

function Slider(){

    return(
        <>
        <SlideCard/>
        
        </>
    )
}

export default Slider