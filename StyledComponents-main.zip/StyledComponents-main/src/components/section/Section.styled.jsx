import styled from "styled-components";

export const StyledSection = styled.section`

`