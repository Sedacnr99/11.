import styled from "styled-components";

export const StyleHeader = styled.header`


 
`;
