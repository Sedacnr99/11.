import styled from "styled-components";

export const StyleFooter = styled.footer`


 
`;
